﻿using BooksDb_Nizomov.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace BooksDb_Nizomov
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static BooksDb_NizomovEntities Db = new BooksDb_NizomovEntities();
    }
}
