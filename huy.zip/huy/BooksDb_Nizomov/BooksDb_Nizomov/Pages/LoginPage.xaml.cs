﻿using BooksDb_Nizomov.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BooksDb_Nizomov.Pages
{
    public partial class LoginPage : Page
    {
        private BooksDb_NizomovEntities VoitiBD = new BooksDb_NizomovEntities();
        public LoginPage()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text;
            string password = PasswordBox.Password;

            var user = VoitiBD.Users.FirstOrDefault(x => x.Login == login && x.PasswordHash == password);

            if (user != null)
            {
                NavigationService.Navigate(new MainPage());
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль", "Ошибка");
            }

        }
    }
}
